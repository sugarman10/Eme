// src/middleware/auth.js
import jwt from 'jsonwebtoken';
import TokenBlacklist from '../models/TokenBlacklist.js';
import User from '../models/User.js';
import logger from '../config/logger.js';

// Lightweight 30s in-memory cache for user active/role verification
const _userStatusCache = new Map();
const USER_STATUS_TTL_MS = 30 * 1000;

async function verifyActiveUser(userId) {
  if (!userId) return null;
  const key = userId.toString();
  const now = Date.now();
  const cached = _userStatusCache.get(key);
  if (cached && now < cached.expiry) {
    return cached.user;
  }
  const dbUser = await User.findById(key).select('isActive role permissions assignedWarehouse').lean();
  if (dbUser) {
    _userStatusCache.set(key, { user: dbUser, expiry: now + USER_STATUS_TTL_MS });
  }
  return dbUser;
}

/**
 * JWT Authentication Middleware
 *
 * Verifies JWT token and checks against blacklist for secure logout.
 * Attaches user payload to req.user if valid.
 *
 * Security Features:
 * - Token verification with secret
 * - Token blacklist check (for logout/revocation)
 * - isActive check for banned users
 */
export function requireAuth(roles = []) {
  return async (req, res, next) => {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';

    if (!token) {
      return res.status(401).json({ message: 'Unauthorized: No token provided' });
    }

    try {
      // Step 1: Verify token signature and expiration
      const payload = jwt.verify(token, process.env.JWT_SECRET);

      // Step 2: Check if token is blacklisted (logged out or revoked)
      const isBlacklisted = await TokenBlacklist.isBlacklisted(token);
      if (isBlacklisted) {
        logger.logWarning('Blacklisted token used', {
          userId: payload.id,
          ip: req.ip,
        });
        return res.status(401).json({
          message: 'Token has been revoked. Please login again.',
          code: 'TOKEN_REVOKED',
        });
      }

      // Step 3: Check if user account is active (token payload + live DB check)
      const userId = payload.id || payload._id;
      const dbUser = await verifyActiveUser(userId);
      if (payload.isActive === false || (dbUser && dbUser.isActive === false)) {
        return res.status(403).json({
          message: 'Account is banned or inactive',
          code: 'ACCOUNT_INACTIVE',
        });
      }

      if (dbUser?.role) {
        payload.role = dbUser.role;
      }

      const allowedRoles = Array.isArray(roles) ? roles : [roles];
      if (allowedRoles.length > 0 && !allowedRoles.includes(payload.role)) {
        return res.status(403).json({
          message: 'Forbidden: Insufficient role',
          code: 'ROLE_FORBIDDEN',
        });
      }

      // Attach user payload to request
      req.user = payload;
      req.token = token; // Store token for potential logout use

      return next();
    } catch (error) {
      // Handle specific JWT errors
      if (error.name === 'TokenExpiredError') {
        return res.status(401).json({
          message: 'Token has expired. Please login again.',
          code: 'TOKEN_EXPIRED',
        });
      }

      if (error.name === 'JsonWebTokenError') {
        return res.status(401).json({
          message: 'Invalid token',
          code: 'TOKEN_INVALID',
        });
      }

      // Log unexpected errors
      logger.error('Auth middleware error:', error.message);
      return res.status(401).json({ message: 'Authentication failed' });
    }
  };
}

/**
 * Optional Auth Middleware
 *
 * Similar to requireAuth but doesn't reject if no token is provided.
 * Useful for endpoints that work differently for authenticated vs anonymous users.
 */
export function optionalAuth() {
  return async (req, res, next) => {
    const h = req.headers.authorization || '';
    const token = h.startsWith('Bearer ') ? h.slice(7) : '';

    if (!token) {
      req.user = null;
      return next();
    }

    try {
      const payload = jwt.verify(token, process.env.JWT_SECRET);

      // Check blacklist
      const isBlacklisted = await TokenBlacklist.isBlacklisted(token);
      if (isBlacklisted) {
        req.user = null;
        return next();
      }

      if (payload.isActive === false) {
        req.user = null;
        return next();
      }

      req.user = payload;
      req.token = token;
      return next();
    } catch {
      req.user = null;
      return next();
    }
  };
}
