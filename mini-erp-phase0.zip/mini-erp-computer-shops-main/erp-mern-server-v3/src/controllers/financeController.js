/**
 * Finance Controller
 * Handles receipt creation and retrieval with proper separation of concerns.
 *
 * Refactored from routes/finance.js to improve code organization.
 * Now uses journalEntryService for automatic journal entries.
 */

import mongoose from 'mongoose';
import Receipt from '../models/Receipt.js';
import Account from '../models/Account.js';
import JournalEntry from '../models/JournalEntry.js';
import Transaction from '../models/Transaction.js';
import User from '../models/User.js';
import logger from '../config/logger.js';
import { postJournalEntry, JournalValidationError } from '../services/journalEntryService.js';
import { auditCreate, auditUpdate } from '../services/auditService.js';
import { startOfDay, endOfDay } from '../utils/dateUtils.js';
import { runPostingTransaction } from '../services/postingService.js';
import CompanySettings from '../models/CompanySettings.js';
import { getSystemAccount } from '../services/systemAccountsService.js';
import { applyFiscalDateFilter } from '../middleware/fiscalPeriod.js';

// ============================================================
// SYSTEM ACCOUNTS CACHE
// ============================================================

/**
 * Cache for system accounts to avoid repeated queries
 * Uses codes from Arabic Chart of Accounts
 */
let _systemAccountsCache = null;
let _cacheTimestamp = 0;
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

/**
 * Get system accounts (with caching)
 * @returns {Promise<Object>} - { cash, bank, ar, wallet }
 */
async function getSystemAccounts(session = null) {
  const now = Date.now();

  // Return cached if valid
  if (_systemAccountsCache && now - _cacheTimestamp < CACHE_TTL) {
    return _systemAccountsCache;
  }

  const [cash, bank, ar, wallet] = await Promise.all([
    getSystemAccount('CASH', session),
    getSystemAccount('BANK', session),
    getSystemAccount('AR', session),
    getSystemAccount('CUSTOMER_WALLET', session),
  ]);

  const result = { cash, bank, ar, wallet };

  // Cache the result
  _systemAccountsCache = result;
  _cacheTimestamp = now;

  return result;
}

/**
 * Clear system accounts cache (useful after seeding)
 */
export function clearSystemAccountsCache() {
  _systemAccountsCache = null;
  _cacheTimestamp = 0;
}

// Dynamic imports to avoid circular dependencies
const getModels = async () => {
  const SalesInvoice = (await import('../models/SalesInvoice.js')).default;
  const Customer = (await import('../models/Customer.js')).default;
  return { SalesInvoice, Customer };
};

const getServices = async () => {
  const { createIncomeTransaction, createExpenseTransaction } = await import('../services/transactionService.js');
  return { createIncomeTransaction, createExpenseTransaction };
};

// ============================================================
// PRIVATE HELPER FUNCTIONS
// ============================================================

/**
 * Process invoice allocations for a receipt
 * @private
 */
async function _processInvoiceAllocations(session, invoices, amount, SalesInvoice) {
  const allocations = [];
  let remainingToAllocate = Number(amount);

  if (!invoices || invoices.length === 0) {
    return { allocations, remainingToAllocate };
  }

  for (const invId of invoices) {
    if (remainingToAllocate <= 0.01) break;

    // Find invoice (with or without session)
    const invoice = session ? await SalesInvoice.findById(invId).session(session) : await SalesInvoice.findById(invId);
    if (!invoice) continue;

    const grand = invoice.totals?.grand || 0;
    const paid = invoice.totals?.paid || 0;
    const due = grand - paid;
    const toPay = Math.min(due, remainingToAllocate);

    if (toPay > 0) {
      invoice.totals.paid = paid + toPay;
      // Avoid floating point issues
      if (invoice.totals.paid >= grand - 0.01) invoice.totals.paid = grand;

      // Save with or without session
      if (session) {
        await invoice.save({ session });
      } else {
        await invoice.save();
      }

      allocations.push({
        invoice: invId,
        amount: toPay,
      });

      remainingToAllocate -= toPay;
    }
  }

  return { allocations, remainingToAllocate };
}

/**
 * Process treasury transactions (single or split)
 * @private
 */
async function _processTreasuryTransactions(session, params, createIncomeTransaction) {
  const { method, amount, splitDetails, treasury, receiptId, date } = params;
  const transactions = [];

  if (method === 'split' && splitDetails && splitDetails.length > 0) {
    const splitTotal = splitDetails.reduce((sum, s) => sum + (Number(s.amount) || 0), 0);
    if (Math.abs(splitTotal - amount) > 0.1) {
      throw new Error('Split total mismatch');
    }

    for (const split of splitDetails) {
      if (Number(split.amount) > 0 && split.treasury) {
        const tx = await createIncomeTransaction(
          {
            amount: split.amount,
            treasury: split.treasury,
            relatedId: receiptId,
            relatedModel: 'Receipt',
            description: `Receipt #${receiptId.toString().slice(-6)} (${split.method})`,
            category: 'sales',
            date,
          },
          session
        );
        if (tx) transactions.push(tx);
      }
    }
  } else {
    if (!treasury) {
      throw new Error('Treasury is required');
    }

    const tx = await createIncomeTransaction(
      {
        amount: amount,
        treasury: treasury,
        relatedId: receiptId,
        relatedModel: 'Receipt',
        description: `Receipt #${receiptId.toString().slice(-6)}`,
        category: 'sales',
        date,
      },
      session
    );
    if (tx) transactions.push(tx);
  }

  return transactions;
}

/**
 * Create journal entry for receipt using journalEntryService
 * @private
 *
 * Uses system accounts:
 * - Dr: Cash (1010) or Bank (1020) based on payment method
 * - Cr: Accounts Receivable (1030)
 */
async function _createReceiptJournalEntry(session, params) {
  const { date, receiptId, method, splitDetails = [], customerName, amount, userId } = params;

  logger.info('🔄 Creating Receipt Journal Entry...');

  // Get system accounts (cached)
  const systemAccounts = await getSystemAccounts(session);

  // Validate required accounts exist
  if (!systemAccounts.ar) {
    throw new Error('حساب ذمم العملاء (1030) غير موجود. نفّذ seed-coa-arabic.js أولاً.');
  }

  const lines = [];

  if (method === 'split' && Array.isArray(splitDetails) && splitDetails.length > 0) {
    for (const split of splitDetails) {
      const splitAmount = Number(split.amount) || 0;
      if (splitAmount <= 0) continue;

      let debitAcc;
      let debitMemo;
      if (split.method === 'bank' || split.method === 'transfer') {
        debitAcc = systemAccounts.bank;
        debitMemo = `تحصيل بنكي مجزأ - ${customerName}`;
      } else if (split.method === 'wallet') {
        debitAcc = systemAccounts.wallet;
        debitMemo = `خصم محفظة مجزأ - ${customerName}`;
      } else {
        debitAcc = systemAccounts.cash;
        debitMemo = `تحصيل نقدي مجزأ - ${customerName}`;
      }

      if (!debitAcc) {
        throw new Error('أحد حسابات النظام المحاسبية المطلوبة للسداد المجزأ غير موجود');
      }

      lines.push({
        accountId: debitAcc._id,
        debit: splitAmount,
        credit: 0,
        memo: debitMemo,
      });
    }
  } else {
    // Single payment method
    let debitAccount;
    let debitMemo;

    if (method === 'bank' || method === 'transfer') {
      if (!systemAccounts.bank) {
        throw new Error('حساب البنك (1020) غير موجود. نفّذ seed-coa-arabic.js أولاً.');
      }
      debitAccount = systemAccounts.bank;
      debitMemo = `تحصيل بنكي - ${customerName}`;
    } else if (method === 'wallet') {
      if (!systemAccounts.wallet) {
        throw new Error('حساب أمانات العملاء (2030) غير موجود. نفّذ seed-coa-arabic.js أولاً.');
      }
      debitAccount = systemAccounts.wallet;
      debitMemo = `خصم من المحفظة - ${customerName}`;
    } else {
      // Default to cash (cash, card, etc.)
      if (!systemAccounts.cash) {
        throw new Error('حساب الصندوق (1010) غير موجود. نفّذ seed-coa-arabic.js أولاً.');
      }
      debitAccount = systemAccounts.cash;
      debitMemo = `تحصيل نقدي - ${customerName}`;
    }

    lines.push({
      accountId: debitAccount._id,
      debit: amount,
      credit: 0,
      memo: debitMemo,
    });
  }

  // Credit Accounts Receivable
  lines.push({
    accountId: systemAccounts.ar._id,
    debit: 0,
    credit: amount,
    memo: `سداد من ${customerName}`,
  });

  // Create journal entry using journalEntryService
  // Pass session only if available (null for standalone MongoDB)
  const options = session ? { session, updateBalances: true } : { updateBalances: true };

  const journalEntry = await postJournalEntry(
    {
      date,
      referenceType: 'RECEIPT',
      referenceId: receiptId.toString(),
      ref: `RCT-${receiptId.toString().slice(-6)}`,
      note: `سند قبض - ${customerName}`,
      createdBy: userId,
      lines,
    },
    options
  );

  logger.logSuccess(`Receipt JE Created: ${journalEntry._id}`);
  return journalEntry;
}

/**
 * Create reversing journal entry for receipt
 * - Dr: Accounts Receivable (1030)
 * - Cr: Cash/Bank/Wallet (based on method)
 */
async function _createReceiptReversalJournalEntry(session, params) {
  const { date, receiptId, method, splitDetails = [], customerName, amount, userId } = params;

  logger.info('🔄 Creating Receipt Reversal Journal Entry...');

  const systemAccounts = await getSystemAccounts(session);

  if (!systemAccounts.ar) {
    throw new Error('Accounts Receivable (1030) is missing');
  }

  const lines = [
    {
      accountId: systemAccounts.ar._id,
      debit: amount,
      credit: 0,
      memo: `AR restore - ${customerName}`,
    },
  ];

  if (method === 'split' && Array.isArray(splitDetails) && splitDetails.length > 0) {
    for (const split of splitDetails) {
      const splitAmount = Number(split.amount) || 0;
      if (splitAmount <= 0) continue;

      let creditAcc;
      let creditMemo;
      if (split.method === 'bank' || split.method === 'transfer') {
        creditAcc = systemAccounts.bank;
        creditMemo = `Receipt reversal (bank) - ${customerName}`;
      } else if (split.method === 'wallet') {
        creditAcc = systemAccounts.wallet;
        creditMemo = `Receipt reversal (wallet) - ${customerName}`;
      } else {
        creditAcc = systemAccounts.cash;
        creditMemo = `Receipt reversal (cash) - ${customerName}`;
      }

      lines.push({
        accountId: creditAcc._id,
        debit: 0,
        credit: splitAmount,
        memo: creditMemo,
      });
    }
  } else {
    let creditAccount;
    let creditMemo;

    if (method === 'bank' || method === 'transfer') {
      if (!systemAccounts.bank) {
        throw new Error('Bank account (1020) is missing');
      }
      creditAccount = systemAccounts.bank;
      creditMemo = `Receipt reversal - ${customerName}`;
    } else if (method === 'wallet') {
      if (!systemAccounts.wallet) {
        throw new Error('Wallet account (2030) is missing');
      }
      creditAccount = systemAccounts.wallet;
      creditMemo = `Receipt reversal (wallet) - ${customerName}`;
    } else {
      if (!systemAccounts.cash) {
        throw new Error('Cash account (1010) is missing');
      }
      creditAccount = systemAccounts.cash;
      creditMemo = `Receipt reversal - ${customerName}`;
    }

    lines.push({
      accountId: creditAccount._id,
      debit: 0,
      credit: amount,
      memo: creditMemo,
    });
  }

  const options = session ? { session, updateBalances: true } : { updateBalances: true };

  const journalEntry = await postJournalEntry(
    {
      date,
      referenceType: 'RECEIPT',
      referenceId: receiptId.toString(),
      ref: `RCT-REV-${receiptId.toString().slice(-6)}`,
      note: `Receipt reversal - ${customerName}`,
      createdBy: userId,
      lines,
    },
    options
  );

  logger.logSuccess(`Receipt Reversal JE Created: ${journalEntry._id}`);
  return journalEntry;
}

// ============================================================
// PUBLIC CONTROLLER FUNCTIONS
// ============================================================

/**
 * POST /finance/receipts
 * Create a new receipt with full transaction processing
 *
 * SAFETY: Uses MongoDB transaction for atomicity.
 * If journal entry creation fails, the entire receipt is rolled back.
 * This ensures data integrity.
 */
export async function createReceipt(req, res) {
  const { SalesInvoice, Customer } = await getModels();
  const { createIncomeTransaction } = await getServices();

  const {
    customer,
    amount,
    method = 'cash',
    date = new Date(),
    treasury,
    splitDetails = [],
    note = '',
    invoices = [],
  } = req.body;

  // ============ VALIDATION ============
  // 1. Validate required fields
  if (!customer) {
    return res.status(400).json({ message: 'العميل مطلوب (customer is required)' });
  }
  if (!amount || amount <= 0) {
    return res.status(400).json({ message: 'المبلغ مطلوب ويجب أن يكون أكبر من صفر' });
  }

  // 2. Validate treasury (required for single payment)
  // 2. Validate treasury (required for single payment, except wallet)
  if (method !== 'split' && method !== 'wallet' && !treasury) {
    return res.status(400).json({ message: 'الخزينة مطلوبة (treasury is required)' });
  }

  // 3. Validate customer exists
  const customerDoc = await Customer.findById(customer);
  if (!customerDoc) {
    return res.status(400).json({ message: 'العميل غير موجود (Customer not found)' });
  }

  // 3.1 Prevent receipts for Cash Customer
  // العميل النقدي يدفع مباشرة في نقطة البيع - لا حاجة لسندات قبض
  if (customerDoc.isCashCustomer) {
    return res.status(400).json({
      message: 'العميل النقدي لا تُنشأ له سندات قبض - الدفع يتم مباشرة في نقطة البيع',
    });
  }

  // 4. Validate system accounts exist
  try {
    const systemAccounts = await getSystemAccounts();
    if (!systemAccounts.ar) {
      return res.status(400).json({
        message: 'حساب ذمم العملاء (1030) غير موجود. نفّذ seed-coa-arabic.js أولاً.',
      });
    }
    if (!systemAccounts.cash && method !== 'bank' && method !== 'transfer') {
      return res.status(400).json({
        message: 'حساب الصندوق (1010) غير موجود. نفّذ seed-coa-arabic.js أولاً.',
      });
    }
  } catch (accErr) {
    logger.logError('System accounts validation failed', { error: accErr.message });
    return res.status(400).json({ message: 'فشل التحقق من الحسابات: ' + accErr.message });
  }

  // ============ EXECUTE WITH TRANSACTION (REPLICA SET REQUIRED) ============
  try {
    const populated = await runPostingTransaction(async (session) => {
      const customerDocTx = await Customer.findById(customer).session(session);
      if (!customerDocTx) {
        throw new Error('Customer not found');
      }

      if (customerDocTx.isCashCustomer) {
        throw new Error('Cash customer receipts are not allowed');
      }

      // 1. Process invoice allocations (with session)
      const { allocations } = await _processInvoiceAllocations(session, invoices, amount, SalesInvoice);

      // 2. Create Receipt Document
      const [receiptDoc] = await Receipt.create(
        [
          {
            customer,
            date,
            amount,
            method,
            note,
            status: 'posted',
            treasury: method === 'split' ? (splitDetails.find(s => s.method === 'cash')?.treasury || splitDetails[0]?.treasury) : treasury,
            splitDetails: method === 'split' ? splitDetails : [],
            invoices: allocations.map((a) => a.invoice),
            allocations,
          },
        ],
        { session }
      );

      const receiptId = receiptDoc._id;

      // 3. Process Treasury Transactions
      const treasuryTransactions = await _processTreasuryTransactions(
        session,
        {
          method,
          amount,
          splitDetails,
          treasury,
          receiptId,
          date,
        },
        createIncomeTransaction
      );
      const transactionIds = (treasuryTransactions || []).map((tx) => tx._id);

      // 4. Update Customer Balance
      // balance > 0 → customer owes us (مدين)
      // balance < 0 → we owe customer (دائن / باقي لك) — from overpayment
      const currentBalance = customerDocTx.balance || 0;
      const newBalance = currentBalance - amount;
      customerDocTx.balance = Math.round(newBalance * 1000) / 1000; // round to 3 decimals

      // Update USD debt balance
      try {
        const settings = await CompanySettings.getSettings();
        const currentRate = Number(req.body.exchangeRate) || Number(settings?.usdExchangeRate) || 1;
        const paidInUSD = req.body.currency === 'USD'
          ? Number(amount)
          : (currentRate > 0 ? Number((amount / currentRate).toFixed(2)) : 0);
        if (customerDocTx.balanceUSD) {
          customerDocTx.balanceUSD = Math.max(0, Number((customerDocTx.balanceUSD - paidInUSD).toFixed(2)));
        }
      } catch (e) {
        // Non-critical
      }

      await customerDocTx.save({ session });

      // 5. Create Journal Entry
      const journalEntry = await _createReceiptJournalEntry(session, {
        date,
        receiptId,
        method,
        splitDetails,
        customerName: customerDocTx.name,
        amount,
        userId: req.user?._id,
      });

      receiptDoc.journalEntry = journalEntry?._id;
      await receiptDoc.save({ session });

      // 6. Return populated receipt (API response unchanged)
      const populatedReceipt = await Receipt.findById(receiptId)
        .session(session)
        .populate('customer', 'name code phone balance')
        .populate('treasury', 'name type')
        .populate('allocations.invoice', '_id number totals')
        .lean();

      if (populatedReceipt) {
        populatedReceipt.previousBalance = currentBalance;
        populatedReceipt.remainingBalance = customerDocTx.balance;
      }

      // 7. Audit trail (in-transaction)
      await auditCreate('RECEIPT', populatedReceipt, req.user, req.ip, session, {
        action: 'POST',
        journalEntryId: journalEntry?._id,
        transactionIds,
      });

      return populatedReceipt;
    });

    logger.info(`Receipt created successfully: ${populated?._id}`);
    res.status(201).json(populated);
  } catch (error) {
    // Log with appropriate level
    if (error instanceof JournalValidationError) {
      logger.logWarning('Receipt Creation Failed - Journal Validation', {
        error: error.message,
        code: error.code,
      });
    } else {
      logger.logError('Receipt Creation Failed', {
        error: error.message,
        stack: error.stack,
      });
    }

    res.status(400).json({ message: error.message || 'Failed to create receipt' });
  }
}

// ============================================================
// RECEIPT REVERSAL / VOID
// ============================================================

async function _reverseReceipt(req, res, targetStatus) {
  const { SalesInvoice, Customer } = await getModels();
  const { createExpenseTransaction } = await getServices();

  try {
    const { id } = req.params;

    const receiptId = await runPostingTransaction(async (session) => {
      const receipt = await Receipt.findById(id).session(session);
      if (!receipt) {
        throw new Error('Receipt not found');
      }

      if (receipt.status !== 'posted') {
        throw new Error('Only posted receipts can be reversed or voided');
      }

      const beforeState = receipt.toObject();

      // Reverse invoice allocations
      if (Array.isArray(receipt.allocations)) {
        for (const alloc of receipt.allocations) {
          const invoice = await SalesInvoice.findById(alloc.invoice).session(session);
          if (!invoice) continue;
          const paid = invoice.totals?.paid || 0;
          invoice.totals.paid = Math.max(0, paid - (Number(alloc.amount) || 0));
          await invoice.save({ session });
        }
      }

      // Reverse treasury transactions
      const receiptTransactions = await Transaction.find({
        relatedModel: 'Receipt',
        relatedId: receipt._id,
      }).session(session);

      const reversalTransactions = [];
      for (const tx of receiptTransactions) {
        const reverseTx = await createExpenseTransaction(
          {
            amount: tx.amount,
            treasury: tx.treasury,
            relatedId: receipt._id,
            relatedModel: 'Receipt',
            description: `Receipt reversal #${receipt._id.toString().slice(-6)}`,
            category: 'sales',
            date: new Date(),
          },
          session
        );
        if (reverseTx) reversalTransactions.push(reverseTx);
      }
      const reversalTransactionIds = reversalTransactions.map((tx) => tx._id);


      // Restore customer balance — simply add back the receipt amount
      // (balance may go positive = customer owes again, or stay negative = still has credit)
      if (receipt.customer) {
        await Customer.findByIdAndUpdate(
          receipt.customer,
          { $inc: { balance: Number(receipt.amount || 0) } },
          { session }
        );
      }

      const customerDoc = receipt.customer ? await Customer.findById(receipt.customer).session(session) : null;

      const journalEntry = await _createReceiptReversalJournalEntry(session, {
        date: new Date(),
        receiptId: receipt._id,
        method: receipt.method,
        splitDetails: receipt.splitDetails || [],
        customerName: customerDoc?.name || 'Customer',
        amount: receipt.amount,
        userId: req.user?._id,
      });

      receipt.status = targetStatus;
      await receipt.save({ session });

      await auditUpdate('RECEIPT', receipt._id, beforeState, receipt, req.user, req.ip, session, {
        action: targetStatus === 'void' ? 'VOID' : 'REVERSE',
        journalEntryId: journalEntry?._id,
        transactionIds: reversalTransactionIds,
        walletReversalAmount: receipt.method === 'wallet' ? receipt.amount : 0,
      });

      return receipt._id;
    });

    const populated = await Receipt.findById(receiptId)
      .populate('customer', 'name code')
      .populate('allocations.invoice', '_id totals')
      .lean();

    res.json({
      message: targetStatus === 'void' ? 'Receipt voided' : 'Receipt reversed',
      receipt: populated,
    });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
}

export async function voidReceipt(req, res) {
  return _reverseReceipt(req, res, 'void');
}

export async function reverseReceipt(req, res) {
  return _reverseReceipt(req, res, 'reversed');
}

/**
 * GET /finance/receipts
 * Retrieve all receipts with populated references
 */
export async function getReceipts(req, res) {
  res.set('Cache-Control', 'no-store');
  logger.http('GET /receipts called');

  try {
    const filter = {};
    if (req.query.customer) filter.customer = req.query.customer;
    if (req.query.status)   filter.status   = req.query.status;

    applyFiscalDateFilter(req, filter, 'date');

    const data = await Receipt.find(filter)
      .populate('customer', 'name code phone balance')
      .populate('treasury', 'name type')
      .populate('allocations.invoice', '_id number totals date')
      .sort({ date: -1, createdAt: -1 });

    logger.info(`Fetched ${data.length} receipts (populated)`);
    res.json(data);
  } catch (err) {
    logger.logWarning('Fetching receipts without populate due to error', { error: err.message });
    try {
      const filter = {};
      if (req.query.customer) filter.customer = req.query.customer;
      const data = await Receipt.find(filter).sort({ date: -1, createdAt: -1 });
      logger.info(`Fetched ${data.length} receipts (raw fallback)`);
      res.json(data);
    } catch (fallbackErr) {
      logger.logError('Critical Error fetching receipts', { error: fallbackErr.message });
      res.status(500).json({ message: 'Failed to fetch receipts' });
    }
  }
}


// ============================================================
// TRIAL BALANCE REPORT
// ============================================================

/**
 * GET /finance/reports/trial-balance
 *
 * Cumulative Trial Balance Report
 * Aggregates all journal entries up to a given date.
 *
 * Query Params:
 * - to (required): End date (YYYY-MM-DD)
 * - from (optional): Start date, if omitted calculates from oldest entry
 *
 * Balance Rules:
 * - Assets/Expenses: balance = debitTotal - creditTotal
 * - Liabilities/Equity/Revenue: balance = creditTotal - debitTotal
 */
// ============================================================
// REPORT DATA HELPERS
// ============================================================

/**
 * Calculate Trial Balance Data
 * @private
 */
async function _getTrialBalanceData(from, to) {
  const JournalEntry = (await import('../models/JournalEntry.js')).default;

  // Build date filter
  const dateFilter = {};
  const endDate = endOfDay(new Date(to));
  dateFilter.$lte = endDate;

  if (from) {
    const startDate = startOfDay(new Date(from));
    dateFilter.$gte = startDate;
  }

  // Aggregation Pipeline
  const pipeline = [
    { $match: { date: dateFilter } },
    { $unwind: '$lines' },
    {
      $group: {
        _id: '$lines.account',
        debitTotal: { $sum: '$lines.debit' },
        creditTotal: { $sum: '$lines.credit' },
      },
    },
    {
      $lookup: {
        from: 'accounts',
        localField: '_id',
        foreignField: '_id',
        as: 'accountInfo',
      },
    },
    {
      $unwind: {
        path: '$accountInfo',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $project: {
        _id: 0,
        accountId: '$_id',
        code: { $ifNull: ['$accountInfo.code', 'UNKNOWN'] },
        name: { $ifNull: ['$accountInfo.name', 'حساب غير معروف'] },
        type: { $ifNull: ['$accountInfo.type', 'asset'] },
        debitTotal: { $round: ['$debitTotal', 2] },
        creditTotal: { $round: ['$creditTotal', 2] },
      },
    },
    { $sort: { code: 1 } },
  ];

  const rawResults = await JournalEntry.aggregate(pipeline);

  // Calculate balance
  const accounts = rawResults.map((acc) => {
    let balance;
    if (acc.type === 'asset' || acc.type === 'expense') {
      balance = acc.debitTotal - acc.creditTotal;
    } else {
      balance = acc.creditTotal - acc.debitTotal;
    }
    return {
      ...acc,
      balance: Math.round(balance * 100) / 100,
    };
  });

  // Totals
  const totalDebit = accounts.reduce((sum, acc) => sum + acc.debitTotal, 0);
  const totalCredit = accounts.reduce((sum, acc) => sum + acc.creditTotal, 0);
  const isBalanced = Math.abs(totalDebit - totalCredit) < 0.01;

  return {
    period: { from: from || null, to: to },
    accounts,
    totals: {
      totalDebit: Math.round(totalDebit * 100) / 100,
      totalCredit: Math.round(totalCredit * 100) / 100,
      isBalanced,
    },
  };
}

/**
 * GET /finance/reports/trial-balance
 */
export async function getTrialBalance(req, res) {
  const { from, to } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب (to date is required)' });
  }

  logger.http(`GET /reports/trial-balance called (from: ${from || 'oldest'}, to: ${to})`);

  try {
    const data = await _getTrialBalanceData(from, to);
    logger.info(`Trial Balance: ${data.accounts.length} accounts, Balanced: ${data.totals.isBalanced}`);
    res.json(data);
  } catch (err) {
    logger.logError('Trial Balance Report Error', { error: err.message, stack: err.stack });
    res.status(500).json({ message: 'فشل إنشاء ميزان المراجعة' });
  }
}

/**
 * GET /finance/reports/trial-balance/export
 * Export Trial Balance to Excel
 */
export async function exportTrialBalance(req, res) {
  const { from, to } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  logger.http(`GET /reports/trial-balance/export (to: ${to})`);

  try {
    const data = await _getTrialBalanceData(from, to);
    const { generateTrialBalanceExcel } = await import('../services/excelService.js');
    await generateTrialBalanceExcel(data, res);
    res.end();
  } catch (err) {
    logger.logError('Trial Balance Export Error', { error: err.message });
    res.status(500).json({ message: 'فشل تصدير ميزان المراجعة' });
  }
}

// ============================================================
// INCOME STATEMENT REPORT (قائمة الدخل)
// ============================================================

/**
 * GET /finance/reports/income-statement
 *
 * قائمة الدخل التراكمية
 *
 * Query Params:
 * - to (required): تاريخ النهاية (YYYY-MM-DD)
 * - from (optional): تاريخ البداية
 *
 * Calculates:
 * - إجمالي الإيرادات (totalRevenue)
 * - تكلفة البضاعة المباعة (cogs) - حساب 5010
 * - مجمل الربح (grossProfit) = totalRevenue - cogs
 * - المصروفات التشغيلية (operatingExpenses) - باستثناء 5010
 * - صافي الربح (netProfit) = grossProfit - operatingExpenses
 */
/**
 * Calculate Income Statement Data
 * @private
 */
async function _getIncomeStatementData(from, to) {
  const JournalEntry = (await import('../models/JournalEntry.js')).default;

  // Build date filter
  const dateFilter = {};
  const endDate = endOfDay(new Date(to));
  dateFilter.$lte = endDate;

  if (from) {
    const startDate = startOfDay(new Date(from));
    dateFilter.$gte = startDate;
  }

  // Aggregation Pipeline
  const pipeline = [
    { $match: { date: dateFilter } },
    { $unwind: '$lines' },
    {
      $group: {
        _id: '$lines.account',
        debitTotal: { $sum: '$lines.debit' },
        creditTotal: { $sum: '$lines.credit' },
      },
    },
    {
      $lookup: {
        from: 'accounts',
        localField: '_id',
        foreignField: '_id',
        as: 'accountInfo',
      },
    },
    {
      $unwind: {
        path: '$accountInfo',
        preserveNullAndEmptyArrays: true,
      },
    },
    {
      $project: {
        _id: 0,
        accountId: '$_id',
        code: { $ifNull: ['$accountInfo.code', 'UNKNOWN'] },
        name: { $ifNull: ['$accountInfo.name', 'حساب غير معروف'] },
        type: { $ifNull: ['$accountInfo.type', 'expense'] },
        debitTotal: { $round: ['$debitTotal', 2] },
        creditTotal: { $round: ['$creditTotal', 2] },
      },
    },
    { $sort: { code: 1 } },
  ];

  const rawResults = await JournalEntry.aggregate(pipeline);

  // Separate accounts and calculate balances
  const revenueAccounts = [];
  const expenseAccounts = [];
  let cogsAccount = null;

  for (const acc of rawResults) {
    let balance;
    if (acc.type === 'revenue') {
      balance = Math.round((acc.creditTotal - acc.debitTotal) * 100) / 100;
      revenueAccounts.push({ code: acc.code, name: acc.name, balance });
    } else if (acc.type === 'expense') {
      balance = Math.round((acc.debitTotal - acc.creditTotal) * 100) / 100;
      if (acc.code === '5101' || acc.code === '5010') {
        cogsAccount = { code: acc.code, name: acc.name, balance };
      } else {
        expenseAccounts.push({ code: acc.code, name: acc.name, balance });
      }
    }
  }

  // Totals
  const totalRevenue = revenueAccounts.reduce((sum, acc) => sum + acc.balance, 0);
  const cogs = cogsAccount ? cogsAccount.balance : 0;
  const grossProfit = totalRevenue - cogs;
  const operatingExpenses = expenseAccounts.reduce((sum, acc) => sum + acc.balance, 0);
  const netProfit = grossProfit - operatingExpenses;

  return {
    الفترة: { من: from || null, إلى: to },
    حسابات_الإيرادات: revenueAccounts,
    حساب_تكلفة_البضاعة: cogsAccount,
    حسابات_المصروفات_التشغيلية: expenseAccounts,
    الإجماليات: {
      إجمالي_الإيرادات: Math.round(totalRevenue * 100) / 100,
      تكلفة_البضاعة_المباعة: Math.round(cogs * 100) / 100,
      مجمل_الربح: Math.round(grossProfit * 100) / 100,
      المصروفات_التشغيلية: Math.round(operatingExpenses * 100) / 100,
      صافي_الربح: Math.round(netProfit * 100) / 100,
    },
  };
}

/**
 * GET /finance/reports/income-statement
 */
export async function getIncomeStatement(req, res) {
  const { from, to } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  logger.http(`GET /reports/income-statement (from: ${from || 'تراكمي'}, to: ${to})`);

  try {
    const data = await _getIncomeStatementData(from, to);
    logger.info(`Income Statement: Net Profit=${data.الإجماليات.صافي_الربح}`);
    res.json(data);
  } catch (err) {
    logger.logError('Income Statement Report Error', { error: err.message, stack: err.stack });
    res.status(500).json({ message: 'فشل إنشاء قائمة الدخل' });
  }
}

/**
 * GET /finance/reports/income-statement/export
 * Export Income Statement to Excel
 */
export async function exportIncomeStatement(req, res) {
  const { from, to } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  logger.http(`GET /reports/income-statement/export (to: ${to})`);

  try {
    const data = await _getIncomeStatementData(from, to);
    const { generateIncomeStatementExcel } = await import('../services/excelService.js');
    await generateIncomeStatementExcel(data, res);
    res.end();
  } catch (err) {
    logger.logError('Income Statement Export Error', { error: err.message });
    res.status(500).json({ message: 'فشل تصدير قائمة الدخل' });
  }
}

// ============================================================
// CUSTOMER STATEMENT REPORT (كشف حساب العميل)
// ============================================================

/**
 * GET /finance/reports/customer-statement
 *
 * كشف حساب العميل التراكمي
 *
 * Query Params:
 * - customerId (required): معرّف العميل
 * - to (required): تاريخ النهاية (YYYY-MM-DD)
 * - from (optional): تاريخ البداية
 *
 * Data Sources:
 * - Sales Invoices (مدين)
 * - Receipts (دائن)
 */
/**
 * Calculate Customer Statement Data
 * @private
 */
async function _getCustomerStatementData(customerId, from, to) {
  const SalesInvoice = (await import('../models/SalesInvoice.js')).default;
  const Customer = (await import('../models/Customer.js')).default;
  const Receipt = (await import('../models/Receipt.js')).default;
  const SalesReturn = (await import('../models/SalesReturn.js')).default;
  const PaymentVoucher = (await import('../models/PaymentVoucher.js')).default;

  // 1. Verify customer exists
  const customer = await Customer.findById(customerId);
  if (!customer) {
    throw new Error('العميل غير موجود');
  }

  // 2. Build date filter
  const endDate = endOfDay(new Date(to));
  const dateFilter = { $lte: endDate };

  let startDate = null;
  if (from) {
    startDate = startOfDay(new Date(from));
    dateFilter.$gte = startDate;
  }

  // 3. Calculate Opening Balance prior to 'from' date if provided
  let openingBalance = 0;
  if (startDate) {
    const priorFilter = { $lt: startDate };
    const [priorInvoices, priorReceipts, priorReturns, priorVouchers] = await Promise.all([
      SalesInvoice.find({ customer: customerId, date: priorFilter, status: { $ne: 'cancelled' } }).select('totals.grand').lean(),
      Receipt.find({ customer: customerId, date: priorFilter, status: 'posted' }).select('amount').lean(),
      SalesReturn.find({ customer: customerId, createdAt: priorFilter, status: { $ne: 'cancelled' } }).select('totalAmount').lean(),
      PaymentVoucher.find({ customer: customerId, beneficiaryType: 'customer', date: priorFilter, status: 'posted' }).select('amount').lean(),
    ]);

    const priorDebit =
      priorInvoices.reduce((s, i) => s + (Number(i.totals?.grand) || 0), 0) +
      priorVouchers.reduce((s, v) => s + (Number(v.amount) || 0), 0);
    const priorCredit =
      priorReceipts.reduce((s, r) => s + (Number(r.amount) || 0), 0) +
      priorReturns.reduce((s, ret) => s + (Number(ret.totalAmount) || 0), 0);

    openingBalance = Math.round((priorDebit - priorCredit) * 100) / 100;
  }

  // 4. Fetch Invoices (مدين - Debit)
  const invoices = await SalesInvoice.find({
    customer: customerId,
    date: dateFilter,
    status: { $ne: 'cancelled' },
  })
    .select('date number totals')
    .lean();

  // 5. Fetch Receipts (دائن - Credit, posted only)
  const receipts = await Receipt.find({
    customer: customerId,
    date: dateFilter,
    status: 'posted',
  })
    .select('date amount method')
    .lean();

  // 6. Fetch Sales Returns (دائن - Credit)
  const returns = await SalesReturn.find({
    customer: customerId,
    createdAt: dateFilter,
    status: { $ne: 'cancelled' },
  })
    .select('createdAt returnNumber totalAmount')
    .lean();

  // 7. Fetch Payment Vouchers for customer refund (مدين - Debit)
  const vouchers = await PaymentVoucher.find({
    customer: customerId,
    beneficiaryType: 'customer',
    date: dateFilter,
    status: 'posted',
  })
    .select('date number amount')
    .lean();

  // 8. Combine and format transactions
  const transactions = [];

  // Add opening balance transaction if from date specified and non-zero
  if (startDate && openingBalance !== 0) {
    transactions.push({
      التاريخ: startDate,
      النوع: 'رصيد افتتاحي',
      الرقم: '-',
      مدين: openingBalance > 0 ? openingBalance : 0,
      دائن: openingBalance < 0 ? Math.abs(openingBalance) : 0,
      _sortDate: startDate.getTime() - 1,
    });
  }

  // Add invoices as DEBIT
  for (const inv of invoices) {
    transactions.push({
      التاريخ: inv.date,
      النوع: 'فاتورة',
      الرقم: inv.number || inv._id.toString(),
      مدين: Math.round((inv.totals?.grand || 0) * 100) / 100,
      دائن: 0,
      _sortDate: new Date(inv.date).getTime(),
    });
  }

  // Add receipts as CREDIT
  for (const rec of receipts) {
    transactions.push({
      التاريخ: rec.date,
      النوع: 'سند قبض',
      الرقم: rec._id.toString(),
      مدين: 0,
      دائن: Math.round(rec.amount * 100) / 100,
      _sortDate: new Date(rec.date).getTime(),
    });
  }

  // Add sales returns as CREDIT
  for (const ret of returns) {
    transactions.push({
      التاريخ: ret.createdAt,
      النوع: 'مردود مبيعات',
      الرقم: ret.returnNumber || ret._id.toString(),
      مدين: 0,
      دائن: Math.round((ret.totalAmount || 0) * 100) / 100,
      _sortDate: new Date(ret.createdAt).getTime(),
    });
  }

  // Add payment vouchers as DEBIT
  for (const pv of vouchers) {
    transactions.push({
      التاريخ: pv.date,
      النوع: 'سند صرف',
      الرقم: pv.number || pv._id.toString(),
      مدين: Math.round((pv.amount || 0) * 100) / 100,
      دائن: 0,
      _sortDate: new Date(pv.date).getTime(),
    });
  }

  // 9. Sort by date (ascending)
  transactions.sort((a, b) => a._sortDate - b._sortDate);

  // 10. Calculate running balance
  let runningBalance = 0;
  const العمليات = transactions.map((tx) => {
    runningBalance += tx.مدين - tx.دائن;
    return {
      التاريخ: tx.التاريخ,
      النوع: tx.النوع,
      الرقم: tx.الرقم,
      مدين: tx.مدين,
      دائن: tx.دائن,
      الرصيد: Math.round(runningBalance * 100) / 100,
    };
  });

  // 11. Calculate totals
  const إجمالي_المدين = العمليات.reduce((sum, tx) => sum + tx.مدين, 0);
  const إجمالي_الدائن = العمليات.reduce((sum, tx) => sum + tx.دائن, 0);
  const الرصيد_الختامي = Math.round(runningBalance * 100) / 100;

  return {
    العميل: {
      المعرف: customer._id,
      الاسم: customer.name,
      الكود: customer.code || '',
    },
    الفترة: {
      من: from || null,
      إلى: to,
    },
    العمليات,
    الإجماليات: {
      إجمالي_المدين: Math.round(إجمالي_المدين * 100) / 100,
      إجمالي_الدائن: Math.round(إجمالي_الدائن * 100) / 100,
      الرصيد_الختامي,
    },
  };
}

/**
 * GET /finance/reports/customer-statement
 */
export async function getCustomerStatement(req, res) {
  const { customerId, from, to } = req.query;

  if (!customerId) {
    return res.status(400).json({ message: 'معرّف العميل مطلوب' });
  }

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  logger.http(`GET /reports/customer-statement (customer: ${customerId}, from: ${from || 'تراكمي'}, to: ${to})`);

  try {
    const data = await _getCustomerStatementData(customerId, from, to);
    logger.info(`Customer Statement: ${data.العميل.الاسم}, Balance: ${data.الإجماليات.الرصيد_الختامي}`);
    res.json(data);
  } catch (err) {
    logger.logError('Customer Statement Report Error', { error: err.message, stack: err.stack });
    const statusCode = err.message === 'العميل غير موجود' ? 404 : 500;
    res.status(statusCode).json({ message: err.message || 'فشل إنشاء كشف حساب العميل' });
  }
}

/**
 * GET /finance/reports/customer-statement/export
 * Export Customer Statement to Excel
 */
export async function exportCustomerStatement(req, res) {
  const { customerId, from, to } = req.query;

  if (!customerId || !to) {
    return res.status(400).json({ message: 'معرّف العميل وتاريخ النهاية مطلوبان' });
  }

  logger.http(`GET /reports/customer-statement/export (customer: ${customerId}, to: ${to})`);

  try {
    const data = await _getCustomerStatementData(customerId, from, to);
    const { generateCustomerStatementExcel } = await import('../services/excelService.js');
    await generateCustomerStatementExcel(data, res);
    res.end();
  } catch (err) {
    logger.logError('Customer Statement Export Error', { error: err.message });
    res.status(500).json({ message: 'فشل تصدير كشف حساب العميل' });
  }
}

// ============================================================
// AGING REPORT (تقرير أعمار الديون)
// ============================================================

/**
 * GET /finance/reports/aging
 *
 * تقرير أعمار الديون
 *
 * Query Params:
 * - to (required): تاريخ النهاية (YYYY-MM-DD)
 * - bucket (optional): حجم الفترة الزمنية بالأيام (default: 30)
 *
 * Uses:
 * - SalesInvoice.totals.remaining as source of truth
 * - Only confirmed/posted invoices with remaining > 0
 */
/**
 * Calculate Aging Report Data
 * @private
 */
async function _getAgingReportData(to, bucket = 30) {
  const SalesInvoice = (await import('../models/SalesInvoice.js')).default;

  // Validate bucket
  const bucketSize = Number(bucket) || 30;

  const endDate = endOfDay(new Date(to));

  // 1. Fetch invoices with remaining balance > 0
  const invoices = await SalesInvoice.find({
    date: { $lte: endDate },
    'totals.remaining': { $gt: 0.01 },
    status: { $in: ['confirmed', 'posted', 'pending'] }, // Exclude draft, cancelled
  })
    .select('date customer totals.remaining totals.grand number')
    .populate('customer', 'name code')
    .lean();

  // 2. Calculate age and assign to buckets
  const customerMap = new Map();

  for (const inv of invoices) {
    const invoiceDate = new Date(inv.date);
    const ageDays = Math.floor((endDate - invoiceDate) / (1000 * 60 * 60 * 24));
    const remaining = inv.totals?.remaining || 0;

    // Determine bucket
    let bucketKey;
    if (ageDays <= bucketSize) {
      bucketKey = '0_30';
    } else if (ageDays <= bucketSize * 2) {
      bucketKey = '31_60';
    } else if (ageDays <= bucketSize * 3) {
      bucketKey = '61_90';
    } else {
      bucketKey = '90_أكثر';
    }

    // Get or create customer entry
    const customerId = inv.customer?._id?.toString() || 'unknown';
    if (!customerMap.has(customerId)) {
      customerMap.set(customerId, {
        العميل: {
          المعرف: customerId,
          الاسم: inv.customer?.name || 'عميل غير معروف',
          الكود: inv.customer?.code || '',
        },
        '0_30': 0,
        '31_60': 0,
        '61_90': 0,
        '90_أكثر': 0,
        الإجمالي: 0,
      });
    }

    const customerData = customerMap.get(customerId);
    customerData[bucketKey] += remaining;
    customerData['الإجمالي'] += remaining;
  }

  // 3. Convert to array and round values
  const العملاء = Array.from(customerMap.values()).map((c) => ({
    ...c,
    '0_30': Math.round(c['0_30'] * 100) / 100,
    '31_60': Math.round(c['31_60'] * 100) / 100,
    '61_90': Math.round(c['61_90'] * 100) / 100,
    '90_أكثر': Math.round(c['90_أكثر'] * 100) / 100,
    الإجمالي: Math.round(c['الإجمالي'] * 100) / 100,
  }));

  // Sort by total descending
  العملاء.sort((a, b) => b['الإجمالي'] - a['الإجمالي']);

  // 4. Calculate grand totals
  const الإجماليات = {
    '0_30': Math.round(العملاء.reduce((sum, c) => sum + c['0_30'], 0) * 100) / 100,
    '31_60': Math.round(العملاء.reduce((sum, c) => sum + c['31_60'], 0) * 100) / 100,
    '61_90': Math.round(العملاء.reduce((sum, c) => sum + c['61_90'], 0) * 100) / 100,
    '90_أكثر': Math.round(العملاء.reduce((sum, c) => sum + c['90_أكثر'], 0) * 100) / 100,
    الإجمالي: Math.round(العملاء.reduce((sum, c) => sum + c['الإجمالي'], 0) * 100) / 100,
  };

  return {
    إلى: to,
    العملاء,
    الإجماليات,
  };
}

/**
 * GET /finance/reports/aging
 */
export async function getAgingReport(req, res) {
  const { to, bucket = 30 } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  const bucketSize = Number(bucket) || 30;

  logger.http(`GET /reports/aging (to: ${to}, bucket: ${bucketSize})`);

  try {
    const data = await _getAgingReportData(to, bucket);
    logger.info(`Aging Report: ${data.العملاء.length} customers, Total: ${data.الإجماليات.الإجمالي}`);
    res.json(data);
  } catch (err) {
    logger.logError('Aging Report Error', { error: err.message, stack: err.stack });
    res.status(500).json({ message: 'فشل إنشاء تقرير أعمار الديون' });
  }
}

/**
 * GET /finance/reports/aging/export
 * Export Aging Report to Excel
 */
export async function exportAgingReport(req, res) {
  const { to, bucket = 30 } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية مطلوب' });
  }

  logger.http(`GET /reports/aging/export (to: ${to})`);

  try {
    const data = await _getAgingReportData(to, bucket);
    const { generateAgingReportExcel } = await import('../services/excelService.js');
    await generateAgingReportExcel(data, res);
    res.end();
  } catch (err) {
    logger.logError('Aging Report Export Error', { error: err.message });
    res.status(500).json({ message: 'فشل تصدير تقرير أعمار الديون' });
  }
}

/**
 * Get Balance Sheet Report (Cumulative, as of a specific date)
 * GET /api/finance/reports/balance-sheet?to=YYYY-MM-DD
 *
 * Categorizes accounts into Assets, Liabilities, and Equity
 * Verifies: Total Assets = Total Liabilities + Equity
 */
export const getBalanceSheet = async (req, res) => {
  const { to } = req.query;

  if (!to) {
    return res.status(400).json({ message: 'تاريخ النهاية (to) مطلوب' });
  }

  logger.http(`GET /reports/balance-sheet (to: ${to})`);

  try {
    // 1. Get Trial Balance data (cumulative up to 'to' date)
    // Passing null as 'from' ensures we get data from the beginning of time
    const trialBalanceData = await _getTrialBalanceData(null, to);

    // 2. Categorize accounts by type
    const assets = [];
    const liabilities = [];
    const equity = [];

    // Track cumulative P&L for Retained Earnings
    let totalRevenue = 0;
    let totalExpense = 0;

    trialBalanceData.accounts.forEach((acc) => {
      const accountType = acc.type?.toLowerCase();

      // Calculate balance based on account nature
      let balance = 0;
      if (accountType === 'asset') {
        balance = acc.debitTotal - acc.creditTotal;
      } else if (accountType === 'liability' || accountType === 'equity') {
        balance = acc.creditTotal - acc.debitTotal;
      } else if (accountType === 'revenue') {
        // Revenue is normally Credit balance
        balance = acc.creditTotal - acc.debitTotal;
        totalRevenue += balance;
      } else if (accountType === 'expense') {
        // Expense is normally Debit balance
        balance = acc.debitTotal - acc.creditTotal;
        totalExpense += balance;
      }

      const accountData = {
        code: acc.code,
        name: acc.name,
        balance: Number(balance.toFixed(2)),
      };

      if (accountType === 'asset') {
        assets.push(accountData);
      } else if (accountType === 'liability') {
        liabilities.push(accountData);
      } else if (accountType === 'equity') {
        equity.push(accountData);
      }
    });

    // 3. Calculate Retained Earnings (الأرباح المحتجزة)
    // This makes the Balance Sheet balance: Assets = Liabilities + Equity + (Revenue - Expense)
    const retainedEarnings = totalRevenue - totalExpense;

    // Add to Equity
    if (Math.abs(retainedEarnings) > 0.001) {
      equity.push({
        code: '9999',
        name: 'الأرباح المحتجزة (Retained Earnings)',
        balance: Number(retainedEarnings.toFixed(2)),
        isCalculated: true,
      });
    }

    // 4. Calculate totals
    const totalAssets = assets.reduce((sum, a) => sum + a.balance, 0);
    const totalLiabilities = liabilities.reduce((sum, l) => sum + l.balance, 0);
    const totalEquity = equity.reduce((sum, e) => sum + e.balance, 0);
    const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

    // 5. Check balance (with small tolerance for floating point)
    const tolerance = 0.01;
    const isBalanced = Math.abs(totalAssets - totalLiabilitiesAndEquity) < tolerance;

    // 6. Arabic response
    const response = {
      إلى: to,
      الأصول: {
        الحسابات: assets,
        الإجمالي: Number(totalAssets.toFixed(2)),
      },
      الخصوم: {
        الحسابات: liabilities,
        الإجمالي: Number(totalLiabilities.toFixed(2)),
      },
      حقوق_الملكية: {
        الحسابات: equity,
        الإجمالي: Number(totalEquity.toFixed(2)),
      },
      الإجماليات: {
        إجمالي_الأصول: Number(totalAssets.toFixed(2)),
        إجمالي_الخصوم_وحقوق_الملكية: Number(totalLiabilitiesAndEquity.toFixed(2)),
        متوازن: isBalanced,
        الفرق: Number((totalAssets - totalLiabilitiesAndEquity).toFixed(2)),
      },
    };

    res.json(response);
  } catch (err) {
    logger.logError('Balance Sheet Error', { error: err.message });
    res.status(500).json({ message: 'فشل تحميل الميزانية العمومية' });
  }
};

// ============================================================
// ACCOUNT MOVEMENTS & STATEMENTS (سجل حركات شجرة الحسابات)
// ============================================================

const REFERENCE_TYPE_LABELS = {
  SALE_INVOICE: 'فاتورة مبيعات',
  PURCHASE: 'فاتورة مشتريات',
  PURCHASE_INVOICE: 'فاتورة مشتريات',
  SALES_RETURN: 'مردودات مبيعات',
  PURCHASE_RETURN: 'مردودات مشتريات',
  PURCHASE_RETURN_REVERSAL: 'إلغاء إرجاع مشتريات',
  RECEIPT: 'سند قبض',
  PAYMENT: 'سند دفع',
  PAYMENT_VOUCHER: 'سند صرف',
  EXPENSE: 'مصروفات',
  MANUAL: 'قيد يومية يدوي',
  OPENING: 'رصيد افتتاحي',
  ADJUSTMENT: 'قيد تسوية',
};

/**
 * GET /api/finance/accounts/:id/statement
 * Returns detailed statement of account with running balance
 */
export const getAccountStatement = async (req, res) => {
  try {
    const { id } = req.params;
    const { from, to } = req.query;

    let effectiveFrom = from;
    let effectiveTo = to;
    if (!effectiveFrom && req.fiscalPeriod) {
      effectiveFrom = req.fiscalPeriod.startDate.toISOString().split('T')[0];
    }
    if (!effectiveTo && req.fiscalPeriod) {
      effectiveTo = req.fiscalPeriod.endDate.toISOString().split('T')[0];
    }

    const account = await Account.findById(id);
    if (!account) {
      return res.status(404).json({ message: 'الحساب غير موجود' });
    }

    // 1. Calculate Opening Balance before 'effectiveFrom' date if provided
    let openingBalance = 0;
    if (effectiveFrom) {
      const startDate = startOfDay(new Date(effectiveFrom));
      const priorEntries = await JournalEntry.aggregate([
        {
          $match: {
            status: 'POSTED',
            date: { $lt: startDate },
            'lines.account': account._id,
          },
        },
        { $unwind: '$lines' },
        {
          $match: {
            'lines.account': account._id,
          },
        },
        {
          $group: {
            _id: null,
            totalDebit: { $sum: '$lines.debit' },
            totalCredit: { $sum: '$lines.credit' },
          },
        },
      ]);

      if (priorEntries.length > 0) {
        const { totalDebit = 0, totalCredit = 0 } = priorEntries[0];
        if (account.type === 'asset' || account.type === 'expense') {
          openingBalance = Number((totalDebit - totalCredit).toFixed(2));
        } else {
          openingBalance = Number((totalCredit - totalDebit).toFixed(2));
        }
      }
    }

    // 2. Query matching journal entries within date range
    const queryFilter = {
      status: 'POSTED',
      'lines.account': account._id,
    };

    if (effectiveFrom || effectiveTo) {
      queryFilter.date = {};
      if (effectiveFrom) queryFilter.date.$gte = startOfDay(new Date(effectiveFrom));
      if (effectiveTo) queryFilter.date.$lte = endOfDay(new Date(effectiveTo));
    }

    const entries = await JournalEntry.find(queryFilter)
      .sort({ date: 1, createdAt: 1, sequence: 1 })
      .populate('user createdBy', 'name username')
      .lean();

    // 3. Compute running balance chronologically
    let runningBalance = openingBalance;
    let totalDebit = 0;
    let totalCredit = 0;

    const movements = [];
    for (const entry of entries) {
      const matchingLines = entry.lines.filter(
        (l) => l.account && l.account.toString() === account._id.toString()
      );

      for (const line of matchingLines) {
        const debit = Number(line.debit || 0);
        const credit = Number(line.credit || 0);
        totalDebit += debit;
        totalCredit += credit;

        if (account.type === 'asset' || account.type === 'expense') {
          runningBalance = Number((runningBalance + debit - credit).toFixed(2));
        } else {
          runningBalance = Number((runningBalance + credit - debit).toFixed(2));
        }

        movements.push({
          _id: line._id || entry._id,
          journalId: entry._id,
          date: entry.date,
          serialNumber: entry.serialNumber || `JE-${entry._id.toString().slice(-6)}`,
          ref: entry.ref || '',
          referenceType: entry.referenceType,
          referenceTypeName: REFERENCE_TYPE_LABELS[entry.referenceType] || entry.referenceType || 'قيد مالي',
          referenceId: entry.referenceId || '',
          memo: line.memo || entry.note || entry.description || '',
          debit,
          credit,
          runningBalance,
          user: entry.user?.name || entry.createdBy?.name || 'النظام',
        });
      }
    }

    const netMovement =
      account.type === 'asset' || account.type === 'expense'
        ? totalDebit - totalCredit
        : totalCredit - totalDebit;

    const closingBalance = Number((openingBalance + netMovement).toFixed(2));

    res.json({
      account: {
        _id: account._id,
        code: account.code,
        name: account.name,
        type: account.type,
        isSystem: account.isSystem,
        currentStoredBalance: account.balance,
      },
      period: {
        from: from || null,
        to: to || null,
      },
      openingBalance: Number(openingBalance.toFixed(2)),
      totalDebit: Number(totalDebit.toFixed(2)),
      totalCredit: Number(totalCredit.toFixed(2)),
      netMovement: Number(netMovement.toFixed(2)),
      closingBalance,
      count: movements.length,
      movements: movements.reverse(), // latest on top for UI
    });
  } catch (error) {
    logger.error('Error in getAccountStatement:', error);
    res.status(500).json({ message: 'فشل استخراج كشف حساب الحركات', error: error.message });
  }
};

/**
 * GET /api/finance/accounts/movements
 * Returns general paginated log of all movements across the chart of accounts
 */
export const getGeneralMovements = async (req, res) => {
  try {
    const { accountId, referenceType, from, to, search, page = 1, limit = 50 } = req.query;

    const pageNum = Math.max(1, parseInt(page) || 1);
    const limitNum = Math.min(200, Math.max(1, parseInt(limit) || 50));
    const skip = (pageNum - 1) * limitNum;

    const matchFilter = { status: 'POSTED' };

    if (from || to) {
      matchFilter.date = {};
      if (from) matchFilter.date.$gte = startOfDay(new Date(from));
      if (to) matchFilter.date.$lte = endOfDay(new Date(to));
    }

    applyFiscalDateFilter(req, matchFilter, 'date');

    if (referenceType && referenceType !== 'ALL') {
      matchFilter.referenceType = referenceType;
    }

    let targetAccountId = null;
    if (accountId && mongoose.isValidObjectId(accountId)) {
      targetAccountId = new mongoose.Types.ObjectId(accountId);
      matchFilter['lines.account'] = targetAccountId;
    }

    const pipeline = [{ $match: matchFilter }, { $unwind: '$lines' }];

    if (targetAccountId) {
      pipeline.push({
        $match: { 'lines.account': targetAccountId },
      });
    }

    if (search && search.trim()) {
      const regex = new RegExp(search.trim(), 'i');
      pipeline.push({
        $match: {
          $or: [
            { ref: regex },
            { serialNumber: regex },
            { note: regex },
            { 'lines.memo': regex },
          ],
        },
      });
    }

    const facetPipeline = [
      ...pipeline,
      {
        $facet: {
          stats: [
            {
              $group: {
                _id: null,
                totalCount: { $sum: 1 },
                totalDebit: { $sum: '$lines.debit' },
                totalCredit: { $sum: '$lines.credit' },
              },
            },
          ],
          movements: [
            { $sort: { date: -1, createdAt: -1 } },
            { $skip: skip },
            { $limit: limitNum },
            {
              $lookup: {
                from: 'accounts',
                localField: 'lines.account',
                foreignField: '_id',
                as: 'accountDetails',
              },
            },
            {
              $lookup: {
                from: 'users',
                localField: 'user',
                foreignField: '_id',
                as: 'userDetails',
              },
            },
          ],
        },
      },
    ];

    const [result] = await JournalEntry.aggregate(facetPipeline);

    const stats = result?.stats?.[0] || { totalCount: 0, totalDebit: 0, totalCredit: 0 };
    const rawMovements = result?.movements || [];

    const movements = rawMovements.map((m) => {
      const acc = m.accountDetails?.[0] || null;
      const user = m.userDetails?.[0] || null;
      return {
        _id: m.lines?._id || m._id,
        journalId: m._id,
        date: m.date,
        serialNumber: m.serialNumber || `JE-${m._id.toString().slice(-6)}`,
        ref: m.ref || '',
        referenceType: m.referenceType,
        referenceTypeName: REFERENCE_TYPE_LABELS[m.referenceType] || m.referenceType || 'قيد مالي',
        memo: m.lines?.memo || m.note || '',
        debit: Number(m.lines?.debit || 0),
        credit: Number(m.lines?.credit || 0),
        account: acc ? { _id: acc._id, code: acc.code, name: acc.name, type: acc.type } : null,
        user: user ? user.name || user.username : 'النظام',
      };
    });

    res.json({
      movements,
      total: stats.totalCount,
      totalDebit: Number(stats.totalDebit.toFixed(2)),
      totalCredit: Number(stats.totalCredit.toFixed(2)),
      page: pageNum,
      limit: limitNum,
      totalPages: Math.ceil(stats.totalCount / limitNum),
    });
  } catch (error) {
    logger.error('Error fetching general movements:', error);
    res.status(500).json({ message: 'فشل تحميل سجل الحركات المالية', error: error.message });
  }
};
